"""
Zain KSA (Tadawul: 7030) Stock Analysis
Author: Amal
----------------------------------------
Goal: Analyze ~16 years of Zain KSA daily price data to understand
how two major corporate restructurings (2012 and 2020) affected
price behavior and volatility, and build the technical indicators
a Data/BI analyst would use to monitor a stock like this.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

plt.rcParams["figure.figsize"] = (12, 5)
plt.rcParams["axes.grid"] = True
plt.rcParams["grid.alpha"] = 0.3

RAW_PATH = "/mnt/user-data/uploads/Mobile_Telecommunications_Company_Saudi_Arabia.csv"
OUT_DATA = "/home/claude/zain_project/data"
OUT_CHARTS = "/home/claude/zain_project/charts"

# ---------------------------------------------------------------
# 1. LOAD & CLEAN
# ---------------------------------------------------------------
df = pd.read_csv(RAW_PATH)
df["Date"] = pd.to_datetime(df["Date"])
df = df.sort_values("Date").reset_index(drop=True)

# Zero-volume days are real (illiquid trading days), not data errors —
# keep them but flag for anyone doing volume-based analysis.
df["zero_volume_day"] = df["Volume"] == 0

df.to_csv(f"{OUT_DATA}/zain_cleaned.csv", index=False)
print(f"Loaded {len(df)} rows from {df['Date'].min().date()} to {df['Date'].max().date()}")
print(f"Zero-volume days: {df['zero_volume_day'].sum()} ({df['zero_volume_day'].mean():.1%})")

# ---------------------------------------------------------------
# 2. CORPORATE EVENTS (from dataset documentation)
# ---------------------------------------------------------------
events = {
    "2012 Capital Reduction\n(SAR 14B -> 4.8B)": "2012-06-01",
    "2020 Restructuring +\nRights Issue": "2020-01-01",
}

# ---------------------------------------------------------------
# 3. DAILY RETURNS & VOLATILITY
# ---------------------------------------------------------------
df["daily_return"] = df["Close"].pct_change()
df["rolling_volatility_30d"] = df["daily_return"].rolling(30).std() * np.sqrt(252)  # annualized

# ---------------------------------------------------------------
# 4. TECHNICAL INDICATORS
# ---------------------------------------------------------------
# Simple Moving Averages
df["SMA_20"] = df["Close"].rolling(20).mean()
df["SMA_50"] = df["Close"].rolling(50).mean()
df["SMA_200"] = df["Close"].rolling(200).mean()

# RSI (14-day)
delta = df["Close"].diff()
gain = delta.clip(lower=0)
loss = -delta.clip(upper=0)
avg_gain = gain.rolling(14).mean()
avg_loss = loss.rolling(14).mean()
rs = avg_gain / avg_loss
df["RSI_14"] = 100 - (100 / (1 + rs))

# MACD (12, 26, 9)
ema12 = df["Close"].ewm(span=12, adjust=False).mean()
ema26 = df["Close"].ewm(span=26, adjust=False).mean()
df["MACD"] = ema12 - ema26
df["MACD_signal"] = df["MACD"].ewm(span=9, adjust=False).mean()
df["MACD_hist"] = df["MACD"] - df["MACD_signal"]

# Bollinger Bands (20-day, 2 std)
df["BB_mid"] = df["Close"].rolling(20).mean()
bb_std = df["Close"].rolling(20).std()
df["BB_upper"] = df["BB_mid"] + 2 * bb_std
df["BB_lower"] = df["BB_mid"] - 2 * bb_std

df.to_csv(f"{OUT_DATA}/zain_with_indicators.csv", index=False)

# ---------------------------------------------------------------
# 5. CHART 1 — Price history with corporate events + SMAs
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(13, 6))
ax.plot(df["Date"], df["Close"], label="Close Price", color="#1f4e79", linewidth=1)
ax.plot(df["Date"], df["SMA_50"], label="SMA 50", color="#e67e22", linewidth=1, alpha=0.8)
ax.plot(df["Date"], df["SMA_200"], label="SMA 200", color="#27ae60", linewidth=1, alpha=0.8)

for label, date in events.items():
    ax.axvline(pd.Timestamp(date), color="red", linestyle="--", alpha=0.6)
    ax.text(pd.Timestamp(date), df["Close"].max() * 0.97, label,
            rotation=0, fontsize=8, color="red", ha="left", va="top")

ax.set_title("Zain KSA (7030.SR) — Price History with Corporate Events (2010–2026)")
ax.set_ylabel("Price (SAR)")
ax.legend(loc="upper left")
ax.xaxis.set_major_locator(mdates.YearLocator(2))
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
plt.tight_layout()
plt.savefig(f"{OUT_CHARTS}/01_price_history_events.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 6. CHART 2 — Rolling 30-day annualized volatility
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(13, 5))
ax.plot(df["Date"], df["rolling_volatility_30d"], color="#8e44ad", linewidth=1)
for label, date in events.items():
    ax.axvline(pd.Timestamp(date), color="red", linestyle="--", alpha=0.5)
ax.set_title("Zain KSA — 30-Day Rolling Annualized Volatility")
ax.set_ylabel("Annualized Volatility")
ax.xaxis.set_major_locator(mdates.YearLocator(2))
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
plt.tight_layout()
plt.savefig(f"{OUT_CHARTS}/02_rolling_volatility.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 7. CHART 3 — RSI (last 3 years, for readability)
# ---------------------------------------------------------------
recent = df[df["Date"] >= df["Date"].max() - pd.Timedelta(days=3*365)]
fig, ax = plt.subplots(figsize=(13, 4))
ax.plot(recent["Date"], recent["RSI_14"], color="#2c3e50", linewidth=1)
ax.axhline(70, color="red", linestyle="--", alpha=0.5, label="Overbought (70)")
ax.axhline(30, color="green", linestyle="--", alpha=0.5, label="Oversold (30)")
ax.set_title("Zain KSA — RSI (14-day), Last 3 Years")
ax.set_ylabel("RSI")
ax.legend(loc="upper left")
plt.tight_layout()
plt.savefig(f"{OUT_CHARTS}/03_rsi_recent.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 8. CHART 4 — Bollinger Bands (last 2 years)
# ---------------------------------------------------------------
recent2 = df[df["Date"] >= df["Date"].max() - pd.Timedelta(days=2*365)]
fig, ax = plt.subplots(figsize=(13, 5))
ax.plot(recent2["Date"], recent2["Close"], color="#1f4e79", linewidth=1, label="Close")
ax.plot(recent2["Date"], recent2["BB_upper"], color="gray", linewidth=0.8, linestyle="--")
ax.plot(recent2["Date"], recent2["BB_lower"], color="gray", linewidth=0.8, linestyle="--")
ax.fill_between(recent2["Date"], recent2["BB_lower"], recent2["BB_upper"], color="gray", alpha=0.15)
ax.set_title("Zain KSA — Bollinger Bands (20-day, 2\u03c3), Last 2 Years")
ax.set_ylabel("Price (SAR)")
ax.legend(loc="upper left")
plt.tight_layout()
plt.savefig(f"{OUT_CHARTS}/04_bollinger_bands.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 9. YEARLY RETURN SUMMARY TABLE
# ---------------------------------------------------------------
df["year"] = df["Date"].dt.year
yearly = df.groupby("year").agg(
    start_price=("Close", "first"),
    end_price=("Close", "last"),
    avg_volume=("Volume", "mean"),
).reset_index()
yearly["annual_return_pct"] = (yearly["end_price"] / yearly["start_price"] - 1) * 100
yearly.to_csv(f"{OUT_DATA}/yearly_returns.csv", index=False)

fig, ax = plt.subplots(figsize=(13, 5))
colors = ["#27ae60" if v >= 0 else "#c0392b" for v in yearly["annual_return_pct"]]
ax.bar(yearly["year"], yearly["annual_return_pct"], color=colors)
ax.axhline(0, color="black", linewidth=0.8)
ax.set_title("Zain KSA — Annual Return by Year (%)")
ax.set_ylabel("Return (%)")
plt.tight_layout()
plt.savefig(f"{OUT_CHARTS}/05_yearly_returns.png", dpi=150)
plt.close()

# ---------------------------------------------------------------
# 10. PRE/POST EVENT VOLATILITY COMPARISON
# ---------------------------------------------------------------
def vol_window(center_date, days=180):
    center = pd.Timestamp(center_date)
    before = df[(df["Date"] >= center - pd.Timedelta(days=days)) & (df["Date"] < center)]
    after = df[(df["Date"] >= center) & (df["Date"] < center + pd.Timedelta(days=days))]
    return before["daily_return"].std() * np.sqrt(252), after["daily_return"].std() * np.sqrt(252)

print("\n--- Event Impact: Annualized Volatility, 180 days before vs after ---")
for label, date in events.items():
    before_vol, after_vol = vol_window(date)
    print(f"{label.replace(chr(10), ' ')}: before={before_vol:.1%}, after={after_vol:.1%}")

print("\nDone. Charts saved to:", OUT_CHARTS)
print("Cleaned data saved to:", OUT_DATA)
